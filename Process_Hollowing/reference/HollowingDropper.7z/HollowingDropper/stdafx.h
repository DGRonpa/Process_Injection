#include <Windows.h>
#include <iostream>
using namespace std;
HANDLE CreateHollowedProcess(LPSTR lpCommandLine, LPSTR lpSourceFile);
